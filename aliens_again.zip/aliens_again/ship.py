import pygame
from pygame.sprite import Sprite
import settings


class Ship:
    
    def __init__(self, settings, screen):
        super(Ship,self).__init__()
        self.screen = screen
        self.settings = settings
        
        # load ship
        self.image = pygame.image.load('images/ship.bmp')
        self.rect = self.image.get_rect()
        self.screen_rect = screen.get_rect()

        r, sr = self.rect, self.screen_rect
        
        # new ship at the bottom
        r.centerx = sr.centerx
        r.bottom = sr.bottom

        self.center = float(self.rect.centerx)

        # movement flag
        self.moving_right = False
        self.moving_left = False

    def update(self):
        r, sr = self.rect, self.screen_rect
        if self.moving_right and r.right < sr.right:
            r.centerx += self.settings.ship_speed_factor
        if self.moving_left and r.left > 0:
            r.centerx -= self.settings.ship_speed_factor

    def blitme(self):
        self.screen.blit(self.image, self.rect)

    def center_ship(self):
        self.center = self.screen_rect.centerx
